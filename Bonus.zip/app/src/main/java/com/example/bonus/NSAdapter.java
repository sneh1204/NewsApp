package com.example.bonus;

public class NSAdapter {
}
